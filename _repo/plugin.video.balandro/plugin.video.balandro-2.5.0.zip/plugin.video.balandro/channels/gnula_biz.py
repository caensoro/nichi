# -*- coding: utf-8 -*-

# Gnula_biz clon de cinefox, con el mismo contenido, pero en otro dominio sin cloudflare

from channels.cinefox import *
