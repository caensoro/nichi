import xbmcaddon
import urllib, os,re,urllib2
import xbmc,xbmcgui
import subprocess
import zipfile
import stat
import shutil
import time


""" BOTONES GUI"""


addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


""" DETECTAR SO """


line9 = 'NO Soportado'
line10 = 'Solo Raspberry Pi'
line11 = 'Solo Linux'
line12 = 'Falta Modulo Acestream'

if xbmc.getCondVisibility('system.platform.linux') and not xbmc.getCondVisibility('system.platform.Android'):
	if "arm" in os.uname()[4]:
		pass
	else :
		xbmcgui.Dialog().ok(addonname, line9, line10)
		exit()
else :
	xbmcgui.Dialog().ok(addonname, line9, line11)
	exit()


""" RUTAS """


ruta = xbmc.translatePath("special://home")
rutaacestream = os.path.join(os.sep, ruta, "userdata", "addon_data", "program.plexus", "acestream")	


""" ELIMINAR ACESTREAM """


if os.path.exists(rutaacestream) :
	if os.geteuid() == 0 :
		shutil.rmtree(rutaacestream)
        else :
		subprocess.call(["sudo", "rm", "-rf", rutaacestream])
else :
	xbmcgui.Dialog().ok(addonname, line12)
	exit()
	
time.sleep(1)
os.mkdir(rutaacestream, 0777)


""" INICIO """


line1 = 'Bienvenido a Plexus-Patcher by Coeman76'
line2 = 'Pulse OK para comenzar'
xbmcgui.Dialog().ok(addonname, line1, line2)
line3 = 'Descargar Acestream'
line8 = 'Pulse OK para continuar'
xbmcgui.Dialog().ok(addonname, line3, line8)


""" DESCARGAR ACESTREAM """


def DownloaderClass(url,dest):
	dp = xbmcgui.DialogProgress()
	dp.create("Plexus-Patcher","Descargando Acestream...")
	urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
	try:
        	percent = min((numblocks*blocksize*100)/filesize, 100)
        	print percent
        	dp.update(percent)
    	except:
        	percent = 100
		dp.update(percent)
        
url ='http://acestreampi.ddns.net/NoTocar/acestream.zip'
DownloaderClass(url, ruta+"/userdata/acestream.zip")


""" DESCOMPRIMIR """


line4 = "Descomprimiendo Archivos"
line7 = "Pulse OK para continuar"
xbmcgui.Dialog().ok(addonname, line4, line7)
zf=zipfile.ZipFile(ruta+'/userdata/acestream.zip', 'r')

for i in zf.namelist():
	zf.extract(i, path=ruta+'/userdata/addon_data/program.plexus')


""" PERMISOS"""


if os.geteuid() == 0 :
	subprocess.call(['chmod', '777', '-R', rutaacestream])
else :
	rutabinario = os.path.join(rutaacestream, "chroot") 
	st = os.stat(rutabinario)
	os.chmod(rutabinario, st.st_mode | stat.S_IEXEC)
	subprocess.call(['sudo', 'chmod', '777', '-R', rutaacestream])


""" ELIMINAR ARCHIVOS"""


from os import remove

remove(ruta+'/userdata/acestream.zip')
line6 = 'Acestream Modificado con Exito'
line5 = 'Pulse OK para Salir'
xbmcgui.Dialog().ok(addonname, line6, line5)
