import xbmcaddon
import urllib, os,re,urllib2
import xbmc,xbmcgui
import time
import subprocess
import zipfile


""" botones gui"""


addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')


""" detectar so y poner rutas """

line9 = 'Sistema NO Soportado'

if os.uname()[1] == "LibreELEC" :
	ruta = "/storage"
elif os.uname()[1] == "osmc" :
	ruta = "/home/osmc"
else :
	xbmcgui.Dialog().ok(addonname, line9)
	exit()	


line1 = 'Bienvenido a Plexus-Patcher by Coeman76'
line2 = 'Pulse OK para comenzar'
xbmcgui.Dialog().ok(addonname, line1, line2)
line3 = 'Descargar Acestream'
line8 = 'Pulse OK para continuar'
xbmcgui.Dialog().ok(addonname, line3, line8)


""" Descarga """


def DownloaderClass(url,dest):
    dp = xbmcgui.DialogProgress()
    dp.create("Plexus-Patcher","Descargando Acestream...")
    urllib.urlretrieve(url,dest,lambda nb, bs, fs, url=url: _pbhook(nb,bs,fs,url,dp))

def _pbhook(numblocks, blocksize, filesize, url=None,dp=None):
    try:
        percent = min((numblocks*blocksize*100)/filesize, 100)
        print percent
        dp.update(percent)
    except:
        percent = 100
        dp.update(percent)
        
url ='http://acestreampi.ddns.net/NoTocar/acestream.zip'
DownloaderClass(url, ruta+"/.kodi/userdata/acestream.zip")


""" Descomprimir"""


line4 = "Descomprimiendo Archivos"
line7 = "Pulse OK para continuar"
xbmcgui.Dialog().ok(addonname, line4, line7)
zf=zipfile.ZipFile(ruta+'/.kodi/userdata/acestream.zip', 'r')
for i in zf.namelist():

    zf.extract(i, path=ruta+'/.kodi/userdata/addon_data/program.plexus')


""" Permisos"""


subprocess.call(['chmod', '-R', '777', ruta+'/.kodi/userdata/addon_data/program.plexus/acestream.'])


""" Eliminar descarga y archivos"""


from os import remove
remove(ruta+'/.kodi/userdata/acestream.zip')
line6 = 'Acestream Modificado con Exito'
line5 = 'Pulse OK para Salir'
xbmcgui.Dialog().ok(addonname, line6, line5)
