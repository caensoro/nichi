#!/usr/bin/python
# -*- coding: utf-8 -*-

'''
    script.skin.helper.backgrounds
    Background service for rotating background images
'''

from resources.lib.backgrounds_updater import BackgroundsUpdater
BackgroundsUpdater().run()
